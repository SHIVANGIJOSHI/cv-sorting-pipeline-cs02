"""
rag_retriever.py - Stage 1 Coarse Hybrid Information Retrieval Engine (Model 1)
Implements dense bi-encoder vector embeddings with in-memory matrix projection
and exact lexical skill coverage.
"""

from typing import List, Dict
import numpy as np
import torch
from sentence_transformers import SentenceTransformer
from schemas import (
    JobDescriptionSchema,
    CandidateStructuredCard,
    Stage1RetrievalResult,
)


class DenseLexicalRetriever:
    """
    Model 1: Bi-Encoder Dense Retrieval paired with Lexical Jaccard/Token Overlap.
    Memory footprint: ~120MB RAM, optimized for CPU execution.
    """

    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        """
        Initializes the dense embedding bi-encoder on CPU.
        """
        # Load lightweight bi-encoder for dense semantic representation
        self.bi_encoder = SentenceTransformer(model_name, device="cpu")
        self.card_index: List[CandidateStructuredCard] = []
        self.dense_matrix: Optional[np.ndarray] = None

    def index_candidates(self, cards: List[CandidateStructuredCard]) -> None:
        """
        Builds the in-memory vector index across all ingested candidate CVs.
        Embeds the structured text cards into normalized L2 unit vectors.
        """
        self.card_index = cards
        
        # Prepare text representations combining extracted skills and sanitized summary
        corpus = [
            f"Skills: {', '.join(card.detected_skills)}. Experience: {card.estimated_experience_years} years. {card.raw_text[:2000]}"
            for card in cards
        ]

        # Compute embeddings as normalized numpy array for fast dot-product cosine similarity
        embeddings = self.bi_encoder.encode(
            corpus,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False
        )
        self.dense_matrix = embeddings

    def compute_lexical_coverage(self, jd_skills: List[str], cv_skills: List[str]) -> float:
        """
        Calculates lexical skill recall: percentage of required JD skills found in CV.
        Returns a score in [0.0, 100.0].
        """
        if not jd_skills:
            return 50.0  # Neutral baseline if JD lists no discrete mandatory skills
        
        jd_set = set([s.lower().strip() for s in jd_skills])
        cv_set = set([s.lower().strip() for s in cv_skills])

        overlap = jd_set.intersection(cv_set)
        coverage = (len(overlap) / len(jd_set)) * 100.0
        return float(min(100.0, coverage))

    def retrieve(
        self, 
        jd: JobDescriptionSchema, 
        w_dense: float = 0.60, 
        w_lexical: float = 0.40
    ) -> List[Stage1RetrievalResult]:
        """
        Performs coarse hybrid retrieval against the Job Description.
        Calculates normalized cosine similarity against dense index + lexical coverage.
        """
        if self.dense_matrix is None or len(self.card_index) == 0:
            return []

        # 1. Encode query (Job Description) to normalized unit vector
        query_text = f"Required Skills: {', '.join(jd.mandatory_skills)}. Min Experience: {jd.min_years_experience} years. {jd.raw_text[:2000]}"
        query_embedding = self.bi_encoder.encode(
            query_text,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False
        )

        # 2. Compute Cosine Similarities via Matrix Dot Product (O(N) vectorized)
        dot_products = np.dot(self.dense_matrix, query_embedding)

        results: List[Stage1RetrievalResult] = []

        for idx, card in enumerate(self.card_index):
            raw_cos = float(dot_products[idx])
            # Rescale cosine similarity [-1.0, 1.0] -> [0.0, 100.0]
            dense_score = max(0.0, min(100.0, ((raw_cos + 1.0) / 2.0) * 100.0))

            # Lexical exact match coverage
            lexical_score = self.compute_lexical_coverage(jd.mandatory_skills, card.detected_skills)

            # Stage 1 hybrid composite
            stage1_composite = (w_dense * dense_score) + (w_lexical * lexical_score)

            results.append(
                Stage1RetrievalResult(
                    candidate_id=card.candidate_id,
                    file_name=card.file_name,
                    dense_similarity_score=round(dense_score, 2),
                    lexical_overlap_score=round(lexical_score, 2),
                    stage1_composite=round(stage1_composite, 2)
                )
            )

        # Sort candidate results by preliminary hybrid score descending
        results.sort(key=lambda x: x.stage1_composite, reverse=True)
        return results