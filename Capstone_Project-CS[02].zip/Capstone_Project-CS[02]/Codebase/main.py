"""
main.py - Unified Command-Line Interface (CLI) Entry Point
Project: Capstone_Project-CS[02] - CV Sorting using LLMs

Usage:
    python main.py --jd_path ./sample_jd.txt --cv_dir ./sample_cvs
    python main.py --jd_path ./sample_jd.txt --cv_dir ./sample_cvs --top_k 5 --output_file ./results.json
"""

import os
import sys
import argparse
from typing import List, Dict

from schemas import (
    CandidateStructuredCard,
    FinalRankingPayload,
    CandidateFinalEvaluation,
)
from parser import DocumentParser
from rag_retriever import DenseLexicalRetriever
from reranker import DeepCrossEncoderReranker


def parse_arguments() -> argparse.Namespace:
    """
    Parses CLI flags for grading and execution flexibility.
    """
    parser = argparse.ArgumentParser(
        description="CS[02]: Two-Stage Cascaded Information Retrieval Engine for CV Sorting"
    )
    parser.add_argument(
        "--jd_path",
        type=str,
        required=True,
        help="Path to the Job Description text/PDF file",
    )
    parser.add_argument(
        "--cv_dir",
        type=str,
        required=True,
        help="Directory containing candidate CV files (.pdf or .txt)",
    )
    parser.add_argument(
        "--top_k",
        type=int,
        default=10,
        help="Number of top-ranked candidates to display in the terminal table (default: 10)",
    )
    parser.add_argument(
        "--output_file",
        type=str,
        default="ranked_results.json",
        help="Path to save the machine-readable JSON ranking payload (default: ranked_results.json)",
    )
    return parser.parse_args()


def display_terminal_table(ranked_candidates: List[CandidateFinalEvaluation], top_k: int) -> None:
    """
    Renders an ASCII tabular representation of the ranked candidate list to stdout.
    """
    display_subset = ranked_candidates[:top_k]

    print("\n" + "=" * 96)
    print(
        f"{'RANK':<5} | {'SCORE':<8} | {'DENSE':<7} | {'LEXICAL':<8} | {'CROSS-ENC':<10} | {'NAME / FILE':<24} | {'FLAG'}"
    )
    print("=" * 96)

    for cand in display_subset:
        flag_str = "[ALERT]" if cand.security_flag else "CLEAN"
        display_label = cand.inferred_name if cand.inferred_name != "Candidate" else cand.file_name
        display_label = display_label[:24]

        print(
            f"{cand.rank:<5} | "
            f"{cand.final_score:<8.2f} | "
            f"{cand.stage1_dense_score:<7.1f} | "
            f"{cand.stage1_lexical_score:<8.1f} | "
            f"{cand.stage2_rerank_score:<10.1f} | "
            f"{display_label:<24} | "
            f"{flag_str}"
        )

    print("=" * 96)


def display_candidate_details(cand: CandidateFinalEvaluation) -> None:
    """
    Prints a detailed qualitative breakdown for the #1 ranked candidate.
    """
    print(f"\n>>> Top Match Highlight (Rank #{cand.rank}): {cand.file_name}")
    print(f"    Inferred Identity   : {cand.inferred_name}")
    print(f"    Composite Fit Score : {cand.final_score:.2f} / 100.00")
    print(
        f"    Rubrics Breakdown   : Tech={cand.rubric_breakdown.technical_depth:.1f}, "
        f"Exp={cand.rubric_breakdown.experience_relevance:.1f}, "
        f"Domain={cand.rubric_breakdown.domain_fit:.1f}, "
        f"Edu={cand.rubric_breakdown.education_certs:.1f}"
    )
    print(f"    Matched Skills      : {', '.join(cand.matched_skills) if cand.matched_skills else 'None'}")
    print(f"    Missing Skills      : {', '.join(cand.missing_mandatory_skills) if cand.missing_mandatory_skills else 'None'}")
    print(f"    Audit Justification : {cand.audit_justification}\n")


def main() -> None:
    args = parse_arguments()

    # 1. Input Path Validation
    if not os.path.exists(args.jd_path):
        print(f"[FATAL ERROR] Job Description file not found at: {args.jd_path}", file=sys.stderr)
        sys.exit(1)

    if not os.path.isdir(args.cv_dir):
        print(f"[FATAL ERROR] CV directory not found at: {args.cv_dir}", file=sys.stderr)
        sys.exit(1)

    print("\n" + "#" * 60)
    print("#  CS[02]: TWO-STAGE INFORMATION RETRIEVAL CV SORTER       #")
    print("#" * 60)

    # 2. Document Parsing & Security Sanitization
    doc_parser = DocumentParser()

    print(f"\n[1/4] Ingesting Job Description from: {args.jd_path}")
    jd_schema = doc_parser.parse_job_description(args.jd_path)
    print(f"      Role Title Identified : {jd_schema.title}")
    print(f"      Mandatory Skills Detected ({len(jd_schema.mandatory_skills)}): {', '.join(jd_schema.mandatory_skills[:6])}")
    print(f"      Minimum Experience Req: {jd_schema.min_years_experience} years")

    supported_exts = (".pdf", ".txt")
    cv_filenames = [
        f for f in os.listdir(args.cv_dir) if f.lower().endswith(supported_exts)
    ]

    if not cv_filenames:
        print(f"[FATAL ERROR] No supported CV files (.pdf, .txt) found in {args.cv_dir}", file=sys.stderr)
        sys.exit(1)

    print(f"\n[2/4] Parsing & Sanitizing {len(cv_filenames)} Candidate CV(s)...")
    candidate_cards: List[CandidateStructuredCard] = []
    cards_lookup: Dict[str, CandidateStructuredCard] = {}

    for idx, fname in enumerate(sorted(cv_filenames), start=1):
        fpath = os.path.join(args.cv_dir, fname)
        cand_id = f"CAND_{idx:03d}"
        card = doc_parser.parse_candidate_cv(fpath, candidate_id=cand_id)
        candidate_cards.append(card)
        cards_lookup[cand_id] = card

    threat_count = sum(1 for c in candidate_cards if c.has_injection_risk)
    if threat_count > 0:
        print(f"      [SECURITY WARNING] Intercepted and neutralized {threat_count} prompt injection attempt(s).")
    else:
        print("      [SECURITY CHECK] All CVs cleared guardrail checks.")

    # 3. Stage 1: Coarse Dense & Lexical Retrieval (Model 1)
    print("\n[3/4] Executing Stage 1: Dense Bi-Encoder Retrieval (sentence-transformers/all-MiniLM-L6-v2)...")
    retriever = DenseLexicalRetriever()
    retriever.index_candidates(candidate_cards)
    stage1_results = retriever.retrieve(jd_schema)
    print(f"      Indexed and scored {len(stage1_results)} candidates in vector space.")

    # 4. Stage 2: Deep Cross-Encoder Reranking & Rubric Evaluation (Model 2)
    print("\n[4/4] Executing Stage 2: Deep Cross-Encoder Reranker (cross-encoder/ms-marco-MiniLM-L-6-v2)...")
    reranker = DeepCrossEncoderReranker()
    final_rankings = reranker.rerank_and_evaluate(jd_schema, cards_lookup, stage1_results)

    # 5. Render Results to stdout
    display_terminal_table(final_rankings, top_k=args.top_k)

    if final_rankings:
        display_candidate_details(final_rankings[0])

    # 6. Save Machine-Readable JSON Output
    output_payload = FinalRankingPayload(
        job_description_path=args.jd_path,
        total_candidates_processed=len(final_rankings),
        top_candidates_count=min(args.top_k, len(final_rankings)),
        ranked_candidates=final_rankings,
    )

    with open(args.output_file, "w", encoding="utf-8") as f_out:
        f_out.write(output_payload.model_dump_json(indent=2))

    print(f"[STATUS] Complete ranking payload successfully exported to: {args.output_file}\n")


if __name__ == "__main__":
    main()