"""
reranker.py - Stage 2 Deep Cross-Encoder Reranker & Rubric Evaluator (Model 2)
Applies joint-attention cross-encoding to candidate CVs against the Job Description,
evaluating fine-grained rubrics and producing calibrated audit justifications.
"""

from typing import List, Dict, Tuple
import numpy as np
import torch
from sentence_transformers import CrossEncoder
from schemas import (
    JobDescriptionSchema,
    CandidateStructuredCard,
    Stage1RetrievalResult,
    RubricScores,
    CandidateFinalEvaluation,
)
from guardrails import SecurityGuardrails


class DeepCrossEncoderReranker:
    """
    Model 2: Cross-Encoder Reranker.
    Computes joint query-document cross-attention and scores multi-attribute rubrics.
    Memory footprint: ~150MB RAM, optimized for CPU execution.
    """

    def __init__(self, model_name: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"):
        """
        Initializes the cross-encoder model on CPU.
        """
        self.cross_encoder = CrossEncoder(model_name, device="cpu")
        self.guardrails = SecurityGuardrails()

    def _predict_pair_score(self, query: str, document: str) -> float:
        """
        Runs the cross-encoder forward pass on a single (query, document) pair.
        Maps raw logit output to a normalized percentage [0.0, 100.0] via sigmoid.
        """
        # Truncate tokens to respect model context window
        pair = [(query[:1000], document[:1500])]
        raw_logit = float(self.cross_encoder.predict(pair)[0])

        # Sigmoid activation function
        probability = 1.0 / (1.0 + np.exp(-raw_logit))
        return float(probability * 100.0)

    def evaluate_rubric(
        self,
        jd: JobDescriptionSchema,
        card: CandidateStructuredCard,
        base_cross_score: float
    ) -> Tuple[RubricScores, List[str], List[str], str]:
        """
        Computes rubric scores across 4 key evaluation dimensions:
        1. Technical Depth
        2. Experience Relevance
        3. Domain Fit
        4. Education & Certifications
        """
        jd_skills_set = set([s.lower().strip() for s in jd.mandatory_skills])
        cv_skills_set = set([s.lower().strip() for s in card.detected_skills])

        matched_skills = sorted(list(jd_skills_set.intersection(cv_skills_set)))
        missing_skills = sorted(list(jd_skills_set.difference(cv_skills_set)))

        # 1. Technical Depth (heavily penalizes missing mandatory skills)
        skill_recall = (len(matched_skills) / len(jd_skills_set)) if jd_skills_set else 0.8
        technical_depth = min(100.0, (0.5 * base_cross_score) + (50.0 * skill_recall))

        # 2. Experience Relevance (evaluates tenure threshold against JD min requirement)
        if jd.min_years_experience > 0:
            exp_ratio = min(1.5, card.estimated_experience_years / jd.min_years_experience)
            experience_relevance = min(100.0, exp_ratio * 70.0 + (0.3 * base_cross_score))
        else:
            experience_relevance = base_cross_score

        # 3. Domain Fit (derived from joint attention cross-encoder score)
        domain_fit = base_cross_score

        # 4. Education & Certifications (baseline proxy with text detection)
        edu_keywords = ["master", "phd", "bachelor", "b.tech", "m.tech", "degree", "certified"]
        has_edu = any(k in card.raw_text.lower() for k in edu_keywords)
        education_certs = 85.0 if has_edu else 65.0

        rubric = RubricScores(
            technical_depth=round(technical_depth, 2),
            experience_relevance=round(experience_relevance, 2),
            domain_fit=round(domain_fit, 2),
            education_certs=round(education_certs, 2),
        )

        # Audit justification summary
        justification = (
            f"Candidate matches {len(matched_skills)}/{len(jd_skills_set)} required skills "
            f"({', '.join(matched_skills[:4]) if matched_skills else 'None'}). "
            f"Estimated tenure: {card.estimated_experience_years:.1f} yrs (Target: {jd.min_years_experience:.1f} yrs). "
            f"Cross-attention alignment score: {base_cross_score:.1f}%."
        )

        return rubric, matched_skills, missing_skills, justification

    def rerank_and_evaluate(
        self,
        jd: JobDescriptionSchema,
        cards_dict: Dict[str, CandidateStructuredCard],
        stage1_results: List[Stage1RetrievalResult]
    ) -> List[CandidateFinalEvaluation]:
        """
        Executes Stage 2 joint-attention reranking and computes final composite scores.
        Formula:
          Final Score = 0.25 * DenseSim + 0.15 * LexicalCoverage + 0.60 * CrossEncoderScore
        """
        final_evaluations: List[CandidateFinalEvaluation] = []

        # Securely wrap JD content to isolate query boundary
        secure_jd_query = self.guardrails.wrap_in_secure_boundary("job_description", jd.raw_text[:1200])

        for s1 in stage1_results:
            card = cards_dict[s1.candidate_id]

            # Securely wrap CV content
            secure_cv_doc = self.guardrails.wrap_in_secure_boundary("candidate_profile", card.raw_text[:1500])

            # Forward pass through Model 2 (Cross-Encoder)
            cross_score = self._predict_pair_score(secure_jd_query, secure_cv_doc)

            # Evaluate Rubric
            rubric, matched, missing, audit = self.evaluate_rubric(jd, card, cross_score)

            # Calibrated Composite Formula
            final_composite = (
                (0.25 * s1.dense_similarity_score) +
                (0.15 * s1.lexical_overlap_score) +
                (0.60 * cross_score)
            )

            # Security adjustment if adversarial pattern was neutralized
            if card.has_injection_risk:
                audit += " [SECURITY NOTE: Adversarial injection payload detected and neutralized.]"

            final_evaluations.append(
                CandidateFinalEvaluation(
                    candidate_id=card.candidate_id,
                    file_name=card.file_name,
                    inferred_name=card.inferred_name,
                    final_score=round(final_composite, 2),
                    stage1_dense_score=s1.dense_similarity_score,
                    stage1_lexical_score=s1.lexical_overlap_score,
                    stage2_rerank_score=round(cross_score, 2),
                    rubric_breakdown=rubric,
                    matched_skills=matched,
                    missing_mandatory_skills=missing,
                    audit_justification=audit,
                    security_flag=card.has_injection_risk,
                )
            )

        # Final deterministic sort: descending by final_score
        final_evaluations.sort(key=lambda x: x.final_score, reverse=True)

        # Assign ordinal ranks (1 to N)
        for rank_idx, cand in enumerate(final_evaluations, start=1):
            cand.rank = rank_idx

        return final_evaluations